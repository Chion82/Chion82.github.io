#!/bin/sh

IFCONFIG=ifconfig

cd $(cd "$(dirname "$0")"; pwd)

source ../interface.conf

if [[ ! -z "$INTERFACE_NAME_FILE" ]];then
    INTERFACE_NAME=$(cat $INTERFACE_NAME_FILE)
fi

$IFCONFIG $INTERFACE_NAME down
