#!/bin/sh

IFCONFIG=ifconfig

cd $(cd "$(dirname "$0")"; pwd)

source ../interface.conf
source ../util/util.sh

if [[ ! -z "$INTERFACE_NAME_FILE" ]];then
    INTERFACE_NAME=$(cat $INTERFACE_NAME_FILE)
fi

MASK_CIDR=$(mask2cidr $MASK)

$IFCONFIG $INTERFACE_NAME $LOCAL_ADDR/$MASK_CIDR up
$IFCONFIG $INTERFACE_NAME mtu $MTU
