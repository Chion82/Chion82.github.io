#!/bin/sh

IPROUTE2=ip

DIR=$(dirname $(readlink -f $0))
if [ ${#DIR} -gt 0 ]; then
  cd $DIR
fi

source ../interface.conf
source ../util/util.sh

if [[ ! -z "$INTERFACE_NAME_FILE" ]];then
    INTERFACE_NAME=$(cat $INTERFACE_NAME_FILE)
fi

MASK_CIDR=$(mask2cidr $MASK)

$IPROUTE2 link set dev $INTERFACE_NAME up
$IPROUTE2 addr add $LOCAL_ADDR/$MASK_CIDR dev $INTERFACE_NAME
$IPROUTE2 link set dev $INTERFACE_NAME mtu $MTU
